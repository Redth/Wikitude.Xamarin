using System;
using MonoTouch.ObjCRuntime;

[assembly: LinkWith ("libWikitudeSDK.a", LinkTarget.ArmV7, IsCxx=true, ForceLoad = true, LinkerFlags="-all_load -lc++ -lsqlite3.0 -lz", Frameworks="AssetsLibrary CoreVideo Security SystemConfiguration CoreMedia AVFoundation CFNetwork CoreLocation CoreMotion MediaPlayer OpenGLES QuartzCore UIKit Foundation CoreGraphics")]
