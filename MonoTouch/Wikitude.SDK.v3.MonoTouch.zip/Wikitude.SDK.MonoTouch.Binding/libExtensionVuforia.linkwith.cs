using System;
using MonoTouch.ObjCRuntime;

[assembly: LinkWith ("libExtensionVuforia.a", LinkTarget.ArmV7, ForceLoad = true)]
